import java.sql.SQLException;


public class TestGUI {

	public static void main(String[] args) {
		Object admin;
		Object user1;
		Object ah;
		
		
		SelectUser user=new SelectUser();
		user.setVisible(true);
		
		
		try {
			Dbconnect.DbCall();
		} catch (InstantiationException | IllegalAccessException
				| ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
