import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JRadioButton;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class SelectUser extends JFrame {

	private JPanel contentPane;
	JTextField textField;

	/**
	 * Launch the application.
	 */
	
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SelectUser frame = new SelectUser();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SelectUser() {
		setTitle("Select User");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 496, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		final JRadioButton rdbtnNewRadioButton = new JRadioButton("");
		rdbtnNewRadioButton.setBounds(145, 114, 51, 23);
		contentPane.add(rdbtnNewRadioButton);
		
		final JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("");
		rdbtnNewRadioButton_1.setBounds(145, 173, 51, 23);
		contentPane.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel = new JLabel("\u0394\u03B9\u03B1\u03C7\u03B5\u03B9\u03C1\u03B9\u03C3\u03C4\u03AE\u03C2");
		lblNewLabel.setBounds(26, 114, 95, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u0391\u03C0\u03BB\u03CC\u03C2 \u03A7\u03C1\u03AE\u03C3\u03C4\u03B7\u03C2");
		lblNewLabel_1.setBounds(26, 173, 113, 14);
		contentPane.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("\u0388\u03BE\u03BF\u03B4\u03BF\u03C2");
		btnNewButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
				
			}
		});
		btnNewButton.setBounds(329, 255, 109, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u0395\u03AF\u03C3\u03BF\u03B4\u03BF\u03C2");
		btnNewButton_1.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				
				String pass = textField.getText();
				
				if (pass.equals("admin") && rdbtnNewRadioButton.isSelected()){
					
					Administrator admin=new Administrator();
					admin.setVisible(true);
					
					
				}else if (rdbtnNewRadioButton_1.isSelected()){
					
					User user1=new User();
				   user1.setVisible(true);
				
				
				}
				
				
			}
		});
		btnNewButton_1.setBounds(329, 221, 109, 23);
		contentPane.add(btnNewButton_1);
		
		textField = new JTextField();
		textField.setBounds(329, 117, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label = new JLabel("\u039A\u03C9\u03B4\u03B9\u03BA\u03CC\u03C2");
		label.setBounds(232, 119, 89, 14);
		contentPane.add(label);
	}
}
