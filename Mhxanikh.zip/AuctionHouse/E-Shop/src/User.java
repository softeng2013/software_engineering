import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class User extends JFrame {

	private JPanel contentPane;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	
	
	SelectUser user=new SelectUser();
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					User frame = new User();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public User() {
		setTitle("User");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 496, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u038C\u03BD\u03BF\u03BC\u03B1");
		lblNewLabel.setBounds(46, 88, 65, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u0395\u03C0\u03B5\u03BE\u03B5\u03C1\u03B3\u03B1\u03C3\u03AF\u03B1");
		lblNewLabel_1.setBounds(46, 148, 89, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("\u039A\u03B1\u03C4\u03AC\u03C1\u03B3\u03B7\u03C3\u03B7");
		lblNewLabel_2.setBounds(46, 210, 89, 14);
		contentPane.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("\u039A\u03B1\u03C4\u03B1\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String name = textField.getText();
				if (!name.equals("")){
					
					AuctionHouse house=new AuctionHouse();
					house.setVisible(true);
					
					
				}
				
			}
		});
		btnNewButton.setBounds(46, 274, 115, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u0395\u03C0\u03B9\u03C3\u03C4\u03C1\u03BF\u03C6\u03AE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				user.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(189, 274, 115, 23);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("\u0388\u03BE\u03BF\u03B4\u03BF\u03C2");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		btnNewButton_2.setBounds(337, 274, 115, 23);
		contentPane.add(btnNewButton_2);
		
		textField = new JTextField();
		textField.setBounds(152, 85, 115, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(152, 177, 115, 20);
		contentPane.add(comboBox);
		
		JLabel label = new JLabel("\u0394\u03B7\u03BC\u03BF\u03C0\u03C1\u03B1\u03C3\u03AF\u03B1");
		label.setBounds(155, 60, 112, 14);
		contentPane.add(label);
		
		JLabel lblNewLabel_3 = new JLabel("\u03A5\u03C0\u03AC\u03C1\u03C7\u03BF\u03C5\u03C3\u03B1 \u0394\u03B7\u03BC\u03BF\u03C0\u03C1\u03B1\u03C3\u03AF\u03B1");
		lblNewLabel_3.setBounds(152, 148, 142, 14);
		contentPane.add(lblNewLabel_3);
	}

}
