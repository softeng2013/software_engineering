import java.sql.*;


public class Dbconnect  {

	
	
		
	public static void DbCall() throws SQLException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		
		int i=0;
		String[] pinCat = new String[50];
		
		
		
		//Database connection
	
			
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		String connectionUrl = "jdbc:mysql://localhost:3306/auction";
		String connectionUser = "root";
		String connectionPassword = "root";
		Connection conn = DriverManager.getConnection(connectionUrl, connectionUser,
		connectionPassword);
			
		
		
		
		Statement stmt = conn.createStatement();
		
		
		ResultSet rs = stmt.executeQuery("SELECT * FROM category");
		while (rs.next())
		{
			
			
		String category = rs.getString("category");
		
		pinCat[i]=category;
		i++;
		
		
		}
		
		
		for(int j = 0; j < i; j++)
		
			System.out.println("Category: " + pinCat[j]);
		
	
     }
	
		
	

}