import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class AuctionHouse extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AuctionHouse frame = new AuctionHouse();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * 
	 */
	
	
	
	public AuctionHouse() {
		setTitle("Auction House");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 496, 384);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel label = new JLabel("\u038C\u03BD\u03BF\u03BC\u03B1");
		label.setBounds(24, 46, 64, 14);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(138, 43, 86, 20);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JLabel label_1 = new JLabel("\u0394\u03B9\u03AC\u03C1\u03BA\u03B5\u03B9\u03B1");
		label_1.setBounds(24, 100, 78, 14);
		contentPane.add(label_1);
		
		textField_1 = new JTextField();
		textField_1.setBounds(138, 97, 86, 20);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u03A4\u03B9\u03BC\u03AE");
		lblNewLabel.setBounds(24, 145, 64, 14);
		contentPane.add(lblNewLabel);
		
		textField_2 = new JTextField();
		textField_2.setBounds(138, 142, 86, 20);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel label_2 = new JLabel("\u039A\u03B1\u03C4\u03B7\u03B3\u03BF\u03C1\u03AF\u03B1");
		label_2.setBounds(24, 196, 78, 14);
		contentPane.add(label_2);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(138, 193, 86, 20);
		contentPane.add(comboBox);
		
		JLabel label_3 = new JLabel("\u03A3\u03C7\u03CC\u03BB\u03B9\u03B1");
		label_3.setBounds(295, 46, 64, 14);
		contentPane.add(label_3);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(292, 71, 160, 117);
		contentPane.add(textArea);
		
		JButton btnNewButton = new JButton("\u039A\u03B1\u03C4\u03B1\u03C7\u03CE\u03C1\u03B7\u03C3\u03B7");
		btnNewButton.setBounds(24, 274, 107, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("\u0395\u03C0\u03B9\u03C3\u03C4\u03C1\u03BF\u03C6\u03AE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				User user=new User();
				user.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(178, 274, 101, 23);
		contentPane.add(btnNewButton_1);
		
		JButton button = new JButton("\u0388\u03BE\u03BF\u03B4\u03BF\u03C2");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				System.exit(0);
			}
		});
		button.setBounds(322, 274, 101, 23);
		contentPane.add(button);
	}
}
